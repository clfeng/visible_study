three.js库来自：https://github.com/mrdoob/three.js/，为了大家使用方便，我把three.js等库放到了我的个人小站，直接通过http方式远程引入。

threejs对应包threejs-master下载，可以通过github直接下载，不过可能会经常下载失败，所以我在百度网盘放了几份不同版本，大家可以根据需要选择下载。

threejs-master链接：https://pan.baidu.com/s/14QSM7QDY5xA-CkLuHc7nvA
提取码：5hym
